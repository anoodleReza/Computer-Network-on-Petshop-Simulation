Project: 'jarkom' created on 2022-09-15
Author: John Doe <john.doe@example.com>

No project description was given